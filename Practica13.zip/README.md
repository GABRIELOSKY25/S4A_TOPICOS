Paso 1. Crear la base de datos

Paso 2 Abrir el proyecto en VSC

Paso 3. Generar el entorno virtual (Si ya existe saltrar al siguiente)

Paso 4. Habilitar el entorno virtual